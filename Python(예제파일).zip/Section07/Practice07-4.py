exam = [99, 78, 100, 91, 81, 85, 54, 100, 71, 50]
score = [min(n + 5, 100) for n in exam]
print(score)
