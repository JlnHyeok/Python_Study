for n in range(5, 0, -1):
    print(n)
