name = 'Kai'
print('내 이름은 %s입니다.' % name)

height = 120.5
print('내 키는 %fcm입니다.' % height)

weight = 23.55
print('내 몸무게는 %.1fkg입니다.' % weight)

year, month, day = 2014, 8, 25
print('내 생일은 %d년 %d월 %d일입니다.' % (year, month, day))
