price = 50000
n = int(input('할부 개월 입력 >>> '))
print('매달 내는 돈은 {}원입니다.'.format(price / n))
