a = float(input('첫 번째 실수를 입력하세요 >>> '))
b = float(input('두 번째 실수를 입력하세요 >>> '))
total = a + b
print('{}와 {}의 합은 {}입니다.'.format(a, b, total))
