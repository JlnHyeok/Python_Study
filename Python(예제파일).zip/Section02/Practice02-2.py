car1 = '서울2가1234'
car2 = '10가1234'
car3 = '288가1234'
car_no1 = car1[-4:]
car_no2 = car2[-4:]
car_no3 = car3[-4:]
print(car1, '의 차량번호 4자리는', car_no1, '입니다.')
print(car2, '의 차량번호 4자리는', car_no2, '입니다.')
print(car3, '의 차량번호 4자리는', car_no3, '입니다.')
