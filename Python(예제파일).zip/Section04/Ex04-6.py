a = 10
b = 70
print('a & b : {}'.format(a & b))
print('a | b : {}'.format(a | b))
print('a ^ b : {}'.format(a ^ b))
print('~a : {}'.format(~a))
print('a << 1 : {}'.format(a << 1))
print('a >> 1 : {}'.format(a >> 1))
