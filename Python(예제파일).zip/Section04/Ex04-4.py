a = 15
print('{} > 10 : {}'.format(a, a > 10))
print('{} < 10 : {}'.format(a, a < 10))
print('{} >= 10 : {}'.format(a, a >= 10))
print('{} <= 10 : {}'.format(a, a <= 10))
print('{} == 10 : {}'.format(a, a == 10))
print('{} != 10 : {}'.format(a, a != 10))
