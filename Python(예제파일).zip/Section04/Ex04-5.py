a = 10
b = 0
print('{} > 0 and {} > 0 : {}'.format(a, b, a > 0 and b > 0))
print('{} > 0 or {} > 0 : {}'.format(a, b, a > 0 or b > 0))
print('not {} : {}'.format(a, not a))
print('not {} : {}'.format(b, not b))
