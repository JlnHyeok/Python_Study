age = int(input('몇 살입니까? >>> '))
if age >= 20:
    print('성인')
else:
    print('미성년자')
