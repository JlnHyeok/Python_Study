money = 10000
price = 3000
result = divmod(money, price)
print('빵을 {}개 사고 {}원이 남았습니다.'.format(result[0], result[1]))
