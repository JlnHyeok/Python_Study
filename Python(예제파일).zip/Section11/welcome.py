# welcome() 함수 정의
def welcome():
    print('Hello Python')
    print('Nice to meet you')

welcome()  # welcome() 함수 호출
