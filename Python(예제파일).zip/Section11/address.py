def address():
    str = '우편번호 12345\n'
    str += '서울시 영등포구 여의도동'
    return str

print(address())
