def show(*args):
    for item in args:
        print(item)

show('python') # show 함수 호출, 인수가 1개입니다.
show('happy', 'birthday') # show 함수 호출, 인수가 2개입니다.
