def introduce(name, age):
    print('내 이름은 {}이고, 나이는 {}살입니다.'.format(name, age))

introduce('james', 25)
