file = open('myFile.txt', 'wt')
print('myFile.txt 파일이 생성되었습니다.')
file.close()

'''
with문
with open('myFile.txt', 'wt') as file:
    print('myFile.txt 파일이 생성되었습니다.')
'''
