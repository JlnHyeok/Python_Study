print('안녕 파이썬!')
print('앞으로 잘 부탁해!')
